<?php
include 'koneksi.php';
if (isset($_POST['username'])) {
	$username = $_POST['username'];
	$password = md5($_POST['password']);

	$query = mysqli_query($koneksi, "SELECT * FROM user WHERE username ='$username' AND password ='$password'");

	if (mysqli_num_rows($query) > 0) {
		$_SESSION['user'] = mysqli_fetch_array($query);
		$_SESSION['waktu_login'] = time();
		$_SESSION['icon'] = "success";
		$_SESSION['title'] = "Berhasil";
		$_SESSION['text'] = "Anda Berhasil Login !";
		header('location:index.php');
	} else {
		echo '<script>
      alert("Username atau Password salah !");location.href="login.php"
      </script>';
	}
}
if (!empty($_SESSION['user'])) {
	header('location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/pages-sign-in.html" />

	<!-- CSS Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<title>Login | Perpustakaan</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<main class="d-flex w-100">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							<h1 class="h2">Perpustakaan Kampung Ganesha</h1>
							<p class="lead">
								Login ke akun Anda untuk melanjutkan!
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-3">
									<form method="post">
										<div class="mb-3">
											<label class="form-label">Username</label>
											<input class="form-control form-control-lg" type="text" name="username" placeholder="Masukkan Username anda." />
										</div>
										<div class="mb-3">
											<label class="form-label">Password</label>
											<input class="form-control form-control-lg" type="password" name="password" placeholder="Masukkan Password anda." />
										</div>
										<div class="d-grid gap-2 mt-3">
											<button class="btn btn-lg btn-primary">Sign in</button>
										</div>
									</form>
									<br>
									<p>Belum punya akun? <a href="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#register">Register</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</main>
	<!-- Modal Tambah-->
	<div class="modal fade" id="register" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<div class="col-12">
						<div class="text-center">
							<h1 class="modal-title fs-5" id="staticBackdropLabel">Register</h1>
						</div>
					</div>
				</div>
				<form method="post" action="aksi-crud.php">
					<div class="modal-body">
						<div class="row">
							<div class="mb-3">
								<label class="form-label">Username</label>
								<input type="text" name="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Password</label>
								<input type="password" name="password" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Nama Lengkap</label>
								<input type="text" name="namalengkap" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Email</label>
								<input type="email" name="email" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Alamat</label>
								<input type="text" name="alamat" class="form-control" required>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<div class="col-12">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="register">Simpan</button>
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Akhir Modal Tambah-->
	<script src="js/app.js"></script>

</body>

</html>