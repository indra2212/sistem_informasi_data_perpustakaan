<?php
include "koneksi.php";

if (isset($_POST['tambahuser'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $namalengkap = $_POST['namalengkap'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $level = $_POST['level'];
    $query = mysqli_query($koneksi, "INSERT INTO user (username,password,namalengkap,email,alamat,level) VALUES('$username','$password','$namalengkap','$email','$alamat','$level')");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=user');
    }
}

if (isset($_POST['edituser'])) {
    $id = $_POST['userid'];
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $namalengkap = $_POST['namalengkap'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $level = $_POST['level'];
    $query = mysqli_query($koneksi, "UPDATE user SET username='$username',password='$password',namalengkap='$namalengkap',email='$email',alamat='$alamat',level='$level' WHERE userid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Diubah !";
        header('location:index.php?page=user');
    }
}

if (!empty($_GET['submit'] == 'hapususer')) {
    $id = $_GET['userid'];
    $query = mysqli_query($koneksi, "DELETE FROM user WHERE userid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Dihapus !";
        header('location:index.php?page=user');
    }
}

if (isset($_POST['tambahbuku'])) {
    $kategori_id = $_POST['kategori_id'];
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahunterbit = $_POST['tahunterbit'];
    $query = mysqli_query($koneksi, "INSERT INTO buku (kategori_id,judul,penulis,penerbit,tahunterbit) VALUES('$kategori_id','$judul','$penulis','$penerbit','$tahunterbit')");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=buku');
    }
}

if (isset($_POST['editbuku'])) {
    $id = $_POST['bukuid'];
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahunterbit = $_POST['tahunterbit'];
    $query = mysqli_query($koneksi, "UPDATE buku SET judul='$judul',penulis='$penulis',penerbit='$penerbit',tahunterbit='$tahunterbit' WHERE bukuid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Diubah !";
        header('location:index.php?page=buku');
    }
}

if (!empty($_GET['submit'] == 'hapusbuku')) {
    $id = $_GET['bukuid'];
    $query = mysqli_query($koneksi, "DELETE FROM buku WHERE bukuid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Dihapus !";
        header('location:index.php?page=buku');
    }
}

if (isset($_POST['tambahpeminjaman'])) {
    $userid = $_SESSION['user']['userid'];
    $bukuid = $_POST['bukuid'];
    $tanggalpeminjaman = $_POST['tanggalpeminjaman'];
    $tanggalpengembalian = $_POST['tanggalpengembalian'];
    $statuspeminjaman = $_POST['statuspeminjaman'];
    $query = mysqli_query($koneksi, "INSERT INTO peminjaman (userid,bukuid,tanggalpeminjaman,tanggalpengembalian,statuspeminjaman) VALUES('$userid','$bukuid','$tanggalpeminjaman','$tanggalpengembalian','$statuspeminjaman')");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=peminjaman');
    }
}

if (isset($_POST['editpeminjaman'])) {
    $id = $_POST['peminjamanid'];
    $statuspeminjaman = $_POST['statuspeminjaman'];
    $query = mysqli_query($koneksi, "UPDATE peminjaman SET statuspeminjaman='$statuspeminjaman' WHERE peminjamanid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Diubah !";
        header('location:index.php?page=peminjaman');
    }
}

if (!empty($_GET['submit'] == 'hapuspeminjaman')) {
    $id = $_GET['peminjamanid'];
    $query = mysqli_query($koneksi, "DELETE FROM peminjaman WHERE peminjamanid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Dihapus !";
        header('location:index.php?page=peminjaman');
    }
}

if (isset($_POST['tambahkategori'])) {
    $namakategori = $_POST['namakategori'];
    $query = mysqli_query($koneksi, "INSERT INTO kategoribuku (namakategori) VALUES('$namakategori')");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=kategori buku');
    }
}

if (isset($_POST['editkategori'])) {
    $id = $_POST['kategori_id'];
    $namakategori = $_POST['namakategori'];
    $query = mysqli_query($koneksi, "UPDATE kategoribuku SET namakategori='$namakategori' WHERE kategori_id='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Diubah !";
        header('location:index.php?page=kategori buku');
    }
}

if (!empty($_GET['submit'] == 'hapuskategori')) {
    $id = $_GET['kategori_id'];
    $query = mysqli_query($koneksi, "DELETE FROM kategoribuku WHERE kategori_id='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Dihapus !";
        header('location:index.php?page=kategori buku');
    }
}

if (isset($_POST['tambahkoleksi'])) {
    $userid = $_SESSION['user']['userid'];
    $bukuid = $_POST['bukuid'];
    $query = mysqli_query($koneksi, "INSERT INTO koleksipribadi (userid, bukuid) VALUES('$userid','$bukuid')");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=koleksi pribadi');
    }
}

if (isset($_POST['editkoleksi'])) {
    $id = $_POST['koleksi_id'];
    $bukuid = $_POST['bukuid'];
    $query = mysqli_query($koneksi, "UPDATE koleksipribadi SET bukuid='$bukuid' WHERE koleksi_id=$id");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=koleksi pribadi');
    }
}

if (!empty($_GET['submit'] == 'hapuskoleksi')) {
    $id = $_GET['koleksi_id'];
    $query = mysqli_query($koneksi, "DELETE FROM koleksipribadi WHERE koleksi_id='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Dihapus !";
        header('location:index.php?page=koleksi pribadi');
    }
}

if (isset($_POST['tambahulasan'])) {
    $userid = $_SESSION['user']['userid'];
    $bukuid = $_POST['bukuid'];
    $ulasan = $_POST['ulasan'];
    $rating = $_POST['rating'];
    $query = mysqli_query($koneksi, "INSERT INTO ulasanbuku (userid, bukuid, ulasan, rating) VALUES('$userid','$bukuid','$ulasan','$rating')");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Ditambahkan !";
        header('location:index.php?page=ulasan buku');
    }
}

if (!empty($_GET['submit'] == 'hapusulasan')) {
    $id = $_GET['ulasanid'];
    $query = mysqli_query($koneksi, "DELETE FROM ulasanbuku WHERE ulasanid='$id'");

    if ($query) {
        $_SESSION['icon'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['text'] = "Data Berhasil Dihapus !";
        header('location:index.php?page=ulasan buku');
    }
}

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $namalengkap = $_POST['namalengkap'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $level = 'peminjam';
    $query = mysqli_query($koneksi, "INSERT INTO user (username,password,namalengkap,email,alamat,level) VALUES('$username','$password','$namalengkap','$email','$alamat','$level')");

    if ($query) {
        echo '<script>
        alert("Akun anda telah dibuat !");location.href="login.php"
        </script>';
    }
}
