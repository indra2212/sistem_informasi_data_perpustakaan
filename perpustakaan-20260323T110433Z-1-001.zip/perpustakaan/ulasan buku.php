<h1 class="h3 mb-3">Ulasan Buku</h1>

<div class="row">
    <div class="col-12">
        <div class="card flex-fill">
            <div class="card-body">
                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tambahulasan">+ Tambah Ulasan</button>
                <br><br>
                <table class="table table-bordered table-striped table-hover cell-border" id="ulasanbuku">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Judul</th>
                            <th>Ulasan</th>
                            <th>Rating</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM ulasanbuku INNER JOIN user ON user.userid=ulasanbuku.userid INNER JOIN buku ON buku.bukuid=ulasanbuku.bukuid");
                        while ($data = mysqli_fetch_array($query)) {
                        ?>
                            <tr>
                                <td><?php echo $i ?></td>
                                <td><?php echo $data['namalengkap'] ?></td>
                                <td><?php echo $data['judul'] ?></td>
                                <td><?php echo $data['ulasan'] ?></td>
                                <td><?php echo $data['rating'] ?></td>
                                <td>
                                    <button class="btn btn-danger btn-sm" id="hapusulasan<?php echo $data['ulasanid'] ?>"><i data-feather="trash-2"></i></button>
                                </td>
                            </tr>

                            <!-- SweetAlert Hapus-->
                            <script>
                                // Tambahkan event listener untuk tombol "Hapus Data"
                                document.getElementById('hapusulasan<?php echo $data['ulasanid'] ?>').addEventListener('click', function() {
                                    Swal.fire({
                                        title: 'Konfirmasi',
                                        text: 'Anda yakin ingin menghapus data ini?',
                                        icon: 'warning',
                                        showCancelButton: true,
                                        confirmButtonColor: '#3085d6',
                                        cancelButtonColor: '#d33',
                                        confirmButtonText: 'Ya, Hapus!',
                                        cancelButtonText: 'Batal'
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "aksi-crud.php?submit=hapusulasan&ulasanid=<?php echo $data['ulasanid'] ?>"
                                        }
                                    });
                                });
                            </script>
                            <!--Akhir SweetAlert Hapus-->

                        <?php
                            $i++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal Tambah-->
<div class="modal fade" id="tambahulasan" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Ulasan</h1>
                    </div>
                </div>
            </div>
            <form method="post" action="aksi-crud.php">
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3">
                            <label class="form-label">Judul</label>
                            <select name="bukuid" class="form-select">
                                <?php
                                $query = mysqli_query($koneksi, "SELECT * FROM buku");
                                while ($data = mysqli_fetch_array($query)) {
                                ?>
                                    <option value="<?php echo $data['bukuid'] ?>"><?php echo $data['judul'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ulasan</label>
                            <input type="text" name="ulasan" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Rating</label>
                            <input type="number" name="rating" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-12">
                        <div class="text-center">
                            <button type="submit" class="btn btn-success" name="tambahulasan">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Akhir Modal Tambah-->
<script>
    let table = new DataTable('#ulasanbuku');
</script>