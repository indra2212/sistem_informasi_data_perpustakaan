<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title-mb-0">Selamat datang di Website Perpustakaan Kampung Ganesha</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <?php
                    if (isset($_SESSION['user']['level'])) {
                    ?>
                        <tr>
                            <td width="150">Nama User</td>
                            <td width="1">:</td>
                            <td><?php echo $_SESSION['user']['namalengkap']; ?></td>
                        </tr>
                        <tr>
                            <td width="150">Level User</td>
                            <td width="1">:</td>
                            <td><?php echo $_SESSION['user']['level']; ?></td>
                        </tr>
                    <?php
                    } else {
                    ?>
                        <tr>
                            <td width="150">Nama Siswa</td>
                            <td width="1">:</td>
                            <td><?php echo $_SESSION['user']['nama']; ?></td>
                        </tr>
                    <?php
                    }
                    ?>

                    <tr>
                        <td width="150">Waktu Login</td>
                        <td width="1">:</td>
                        <td>
                            <?php
                            date_default_timezone_set('Asia/Jakarta');
                            setlocale(LC_TIME, 'id_ID');

                            $hariInggris = date('l');
                            $hariIndonesia = [
                                'Sunday' => 'Minggu',
                                'Monday' => 'Senin',
                                'Tuesday' => 'Selasa',
                                'Wednesday' => 'Rabu',
                                'Thursday' => 'Kamis',
                                'Friday' => 'Jumat',
                                'Saturday' => 'Sabtu',
                            ];

                            $bulanInggris = date('F');
                            $bulanIndonesia = [
                                'January' => 'Januari',
                                'February' => 'Februari',
                                'March' => 'Maret',
                                'April' => 'April',
                                'May' => 'Mei',
                                'June' => 'Juni',
                                'July' => 'Juli',
                                'August' => 'Agustus',
                                'September' => 'September',
                                'October' => 'Oktober',
                                'November' => 'November',
                                'December' => 'Desember',
                            ];

                            $hari = $hariIndonesia[$hariInggris];
                            $bulan = $bulanIndonesia[$bulanInggris];
                            $waktu_sekarang = $_SESSION['waktu_login'];
                            $tanggal = date('d') . ' ' . $bulan . ' ' . date('Y') . ' ' . date('H:i:s', $waktu_sekarang) . ' WIB';
                            echo $hari . ', ' . $tanggal;
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>