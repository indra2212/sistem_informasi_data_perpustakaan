<h1 class="h3 mb-3">Peminjaman Buku</h1>

<div class="row">
    <div class="col-12">
        <div class="card flex-fill">
            <div class="card-body">
                <br><br>
                <table class="table table-bordered table-striped table-hover cell-border" id="peminjamanbuku">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Peminjam</th>
                            <th>Buku Yang Dipinjam</th>
                            <th>Tanggal Peminjaman</th>
                            <th>Tanggal Pengembalian</th>
                            <th>Status Peminjaman</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM peminjaman INNER JOIN user ON user.userid=peminjaman.userid INNER JOIN buku ON buku.bukuid=peminjaman.bukuid");
                        while ($data = mysqli_fetch_array($query)) {
                        ?>
                            <tr>
                                <td><?php echo $i ?></td>
                                <td><?php echo $data['namalengkap'] ?></td>
                                <td><?php echo $data['judul'] ?></td>
                                <td><?php echo $data['tanggalpeminjaman'] ?></td>
                                <td><?php echo $data['tanggalpengembalian'] ?></td>
                                <td><?php echo $data['statuspeminjaman'] ?></td>
                                <td>
                                    <?php
                                    if (!empty($_SESSION['user']['level'] == 'Admin')) {
                                    ?>
                                        <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editpeminjaman<?php echo $data['peminjamanid'] ?>"><i data-feather="edit"></i></button>
                                        <button class="btn btn-danger btn-sm" id="hapuspeminjaman<?php echo $data['peminjamanid'] ?>"><i data-feather="trash-2"></i></button>
                                    <?php
                                    } else {
                                    ?>
                                        <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editpeminjaman<?php echo $data['peminjamanid'] ?>"><i data-feather="edit"></i></button>
                                    <?php
                                    }
                                    ?>

                                </td>
                            </tr>
                            <!-- Modal Edit-->
                            <div class="modal fade" id="editpeminjaman<?php echo $data['peminjamanid'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="col-12">
                                                <div class="text-center">
                                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Peminjaman</h1>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" action="aksi-crud.php">
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="mb-3">
                                                        <input type="hidden" name="peminjamanid" class="form-control" value="<?= $data['peminjamanid'] ?>">
                                                        <label class="form-label">Nama Peminjam</label>
                                                        <input type="text" name="namalengkap" class="form-control" value="<?= $data['namalengkap'] ?>" disabled>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Buku Yang Dipinjam</label>
                                                        <input type="text" name="judul" class="form-control" value="<?= $data['judul'] ?>" disabled>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Tanggal Peminjaman</label>
                                                        <input type="text" name="tanggalpeminjaman" class="form-control" value="<?= $data['tanggalpeminjaman'] ?>" disabled>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Tanggal Pengembalian</label>
                                                        <input type="text" name="tanggalpengembalian" class="form-control" value="<?= $data['tanggalpengembalian'] ?>" disabled>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Status Peminjaman</label>
                                                        <input type="text" name="statuspeminjaman" class="form-control" value="<?= $data['statuspeminjaman'] ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="col-12">
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-success" name="editpeminjaman">Simpan</button>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit-->

                            <!-- SweetAlert Hapus-->
                            <script>
                                // Tambahkan event listener untuk tombol "Hapus Data"
                                document.getElementById('hapuspeminjaman<?php echo $data['peminjamanid'] ?>').addEventListener('click', function() {
                                    Swal.fire({
                                        title: 'Konfirmasi',
                                        text: 'Anda yakin ingin menghapus data ini?',
                                        icon: 'warning',
                                        showCancelButton: true,
                                        confirmButtonColor: '#3085d6',
                                        cancelButtonColor: '#d33',
                                        confirmButtonText: 'Ya, Hapus!',
                                        cancelButtonText: 'Batal'
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "aksi-crud.php?submit=hapuspeminjaman&peminjamanid=<?php echo $data['peminjamanid'] ?>"
                                        }
                                    });
                                });
                            </script>
                            <!--Akhir SweetAlert Hapus-->
                        <?php
                            $i++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah-->
<div class="modal fade" id="tambahpeminjaman" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Peminjaman</h1>
                    </div>
                </div>
            </div>
            <form method="post" action="aksi-crud.php">
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3">
                            <label class="form-label">Nama Peminjam</label>
                            <input type="text" name="namalengkap" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Buku yang Dipinjam</label>
                            <select name="bukuid" class="form-select">
                                <?php
                                $query = mysqli_query($koneksi, "SELECT * FROM buku");
                                while ($data = mysqli_fetch_array($query)) {
                                ?>
                                    <option value="<?php echo $data['bukuid'] ?>"><?php echo $data['judul'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Peminjaman</label>
                            <input type="date" name="tanggalpeminjaman" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Pengembalian</label>
                            <input type="date" name="tanggalpengembalian" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status Peminjaman</label>
                            <input type="text" name="statuspeminjaman" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-12">
                        <div class="text-center">
                            <button type="submit" class="btn btn-success" name="tambahpeminjaman">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Akhir Modal Tambah-->

<script>
    let table = new DataTable('#peminjamanbuku');
</script>