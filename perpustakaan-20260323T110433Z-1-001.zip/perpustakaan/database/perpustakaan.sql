-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2024 at 03:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `bukuid` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `tahunterbit` int(11) NOT NULL,
  `jumlah_buku` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`bukuid`, `kategori_id`, `judul`, `penulis`, `penerbit`, `tahunterbit`, `jumlah_buku`) VALUES
(2001, 3001, 'Bawang Putih & Daun Bawang', 'Mang Usep', 'Erlangga', 1933, 9),
(2002, 3002, 'Galih Pemburu Janda', 'Egi Gocar', 'Gudang Garam', 1992, 20),
(2003, 3003, 'Galih & Ratna', 'Jusuf Bahrudin ', 'WOKA', 2001, 10),
(2004, 3004, 'Aku Si Juragan Empang', 'Windah Barusadar', 'Naistudio', 2005, 5),
(2005, 3005, 'Penjual Tempe Yang Jualan Bakso', 'Nadiem Makarim', 'Semen Tiga Roda', 2011, 15),
(2007, 3001, 'Aku Adalah Robot', 'Mr. Lanvoster', 'Samsung Corp', 2023, 18),
(10006, 3003, 'Cara Menjadi Kaya Dalam 20 Menit', 'Nurdin Baharudin', 'Matahari', 2020, 0);

--
-- Triggers `buku`
--
DELIMITER $$
CREATE TRIGGER `del_buku` AFTER DELETE ON `buku` FOR EACH ROW INSERT INTO log_buku VALUES('Hapus data',now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `ins_buku` AFTER INSERT ON `buku` FOR EACH ROW insert into log_buku values('Tambah data',now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updt_buku` AFTER UPDATE ON `buku` FOR EACH ROW INSERT INTO log_buku VALUES('Memperbarui data',now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategoribuku`
--

CREATE TABLE `kategoribuku` (
  `kategori_id` int(11) NOT NULL,
  `namakategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategoribuku`
--

INSERT INTO `kategoribuku` (`kategori_id`, `namakategori`) VALUES
(3001, 'Pelajaran'),
(3002, 'Fabel'),
(3003, 'Umum'),
(3004, 'Dongeng'),
(3005, 'Komik'),
(3006, 'Novel'),
(3009, 'Majalah');

-- --------------------------------------------------------

--
-- Table structure for table `kategoribuku_relasi`
--

CREATE TABLE `kategoribuku_relasi` (
  `kategoribuku_id` int(11) NOT NULL,
  `bukuid` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategoribuku_relasi`
--

INSERT INTO `kategoribuku_relasi` (`kategoribuku_id`, `bukuid`, `kategori_id`) VALUES
(4001, 2004, 3005),
(4002, 2001, 3004),
(4003, 2003, 3003),
(4004, 2002, 3003),
(4005, 2005, 3003);

-- --------------------------------------------------------

--
-- Table structure for table `koleksipribadi`
--

CREATE TABLE `koleksipribadi` (
  `koleksi_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `bukuid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `koleksipribadi`
--

INSERT INTO `koleksipribadi` (`koleksi_id`, `userid`, `bukuid`) VALUES
(5001, 1001, 2003),
(5002, 1002, 2004),
(5003, 1004, 2001),
(5004, 1003, 2005),
(5005, 1005, 2003),
(5010, 1001, 2005),
(5012, 1103, 2002);

-- --------------------------------------------------------

--
-- Table structure for table `log_buku`
--

CREATE TABLE `log_buku` (
  `kejadian` varchar(25) NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_buku`
--

INSERT INTO `log_buku` (`kejadian`, `waktu`) VALUES
('Tambah data', '2024-01-23 11:56:30'),
('Hapus data', '2024-01-23 11:58:43'),
('Memperbarui data', '2024-01-23 12:00:24'),
('Memperbarui data', '2024-01-23 13:30:31'),
('Memperbarui data', '2024-01-23 13:30:31'),
('Memperbarui data', '2024-01-23 13:30:31'),
('Memperbarui data', '2024-01-23 13:30:31'),
('Memperbarui data', '2024-01-23 13:30:31'),
('Memperbarui data', '2024-01-23 13:30:40'),
('Memperbarui data', '2024-01-23 13:31:20'),
('Memperbarui data', '2024-01-23 13:52:47'),
('Tambah data', '2024-01-23 19:27:51'),
('Hapus data', '2024-01-23 20:02:04'),
('Tambah data', '2024-01-24 12:50:20'),
('Hapus data', '2024-02-06 07:39:40'),
('Tambah data', '2024-02-06 07:40:30'),
('Memperbarui data', '2024-02-06 07:40:38'),
('Memperbarui data', '2024-02-06 09:18:18'),
('Memperbarui data', '2024-02-12 09:42:49');

-- --------------------------------------------------------

--
-- Table structure for table `log_user`
--

CREATE TABLE `log_user` (
  `kejadian` varchar(25) NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_user`
--

INSERT INTO `log_user` (`kejadian`, `waktu`) VALUES
('Tambah data', '2024-01-23 11:41:20'),
('Hapus data', '2024-01-23 11:44:27'),
('Memperbarui data', '2024-01-23 11:45:29'),
('Memperbarui data', '2024-01-23 19:15:20'),
('Tambah data', '2024-02-06 07:43:42'),
('Tambah data', '2024-02-06 07:47:20');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `peminjamanid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `bukuid` int(11) NOT NULL,
  `judul` varchar(35) NOT NULL,
  `jumlah_pinjam` int(2) NOT NULL,
  `tanggalpeminjaman` date NOT NULL,
  `tanggalpengembalian` date NOT NULL,
  `statuspeminjaman` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`peminjamanid`, `userid`, `bukuid`, `judul`, `jumlah_pinjam`, `tanggalpeminjaman`, `tanggalpengembalian`, `statuspeminjaman`) VALUES
(6001, 1001, 2004, '', 0, '2024-01-01', '2024-01-02', 'Dikembalikan'),
(6003, 1002, 2003, '', 0, '2024-01-08', '2024-01-12', 'Dikembalikan'),
(6004, 1003, 2005, '', 0, '2024-01-09', '2024-01-11', 'Dikembalikan'),
(6015, 1004, 2007, 'Aku Adalah Robot', 1, '2024-01-01', '2024-01-08', 'Dikembalikan'),
(6017, 1005, 2002, '', 0, '2024-02-07', '2024-02-08', 'Dikembalikan'),
(6018, 1005, 10006, '', 0, '2024-02-11', '2024-02-13', 'Dikembalikan');

--
-- Triggers `peminjaman`
--
DELIMITER $$
CREATE TRIGGER `kurangi_jumlah` AFTER INSERT ON `peminjaman` FOR EACH ROW update buku SET jumlah_buku=jumlah_buku-new.jumlah_pinjam
where bukuid=new.bukuid
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ulasanbuku`
--

CREATE TABLE `ulasanbuku` (
  `ulasanid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `bukuid` int(11) NOT NULL,
  `ulasan` text NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ulasanbuku`
--

INSERT INTO `ulasanbuku` (`ulasanid`, `userid`, `bukuid`, `ulasan`, `rating`) VALUES
(9001, 1001, 2003, 'Cerita ini sangat seru, karena berisi tentang percintaan yang sangat romantis.', 10),
(9002, 1001, 2001, 'Sangat sedih. Karena Adik dan Kakak yang tidak akur', 7),
(9005, 1104, 2004, 'Juragan Empang yang sukses.', 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `level` enum('Admin','Petugas','Peminjam') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `namalengkap`, `email`, `alamat`, `level`) VALUES
(1001, 'rafakalvin19', '202cb962ac59075b964b07152d234b70', 'Rafa Kalvin Allan', 'kalvinrafa7@gmail.com', 'Bakauheni', 'Admin'),
(1002, 'egitsubasa', '202cb962ac59075b964b07152d234b70', 'Egi Tsubasa Ajah', 'egitsubasa001@yahoo.com', 'Banten', 'Petugas'),
(1003, 'udingempol', '202cb962ac59075b964b07152d234b70', 'Udin Gempol Aja', 'udingempol@yahoo.co.id', 'Rumah Sakit', 'Peminjam'),
(1004, 'ambatukamsaber', '202cb962ac59075b964b07152d234b70', 'Muhammad Sobari', 'saberambatukam222@gmail.com', 'Mobile Legend', 'Petugas'),
(1005, 'valentinasparagus', '202cb962ac59075b964b07152d234b70', 'Via Valen Asparagus', 'valesparagus@yahoo.com', 'Jawa Tenggara', 'Peminjam'),
(1103, 'woka', '202cb962ac59075b964b07152d234b70', 'woka', 'woka@gmail.com', 'woka', 'Petugas'),
(1104, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin@ha.com', 'admin', 'Admin');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `del_user` AFTER DELETE ON `user` FOR EACH ROW insert into log_user values('Hapus data',now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `ins_user` AFTER INSERT ON `user` FOR EACH ROW insert into log_user values('Tambah data',now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updt_user` AFTER UPDATE ON `user` FOR EACH ROW insert into log_user values('Memperbarui data',now())
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`bukuid`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Indexes for table `kategoribuku`
--
ALTER TABLE `kategoribuku`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indexes for table `kategoribuku_relasi`
--
ALTER TABLE `kategoribuku_relasi`
  ADD PRIMARY KEY (`kategoribuku_id`),
  ADD KEY `kategori_id` (`kategori_id`),
  ADD KEY `bukuid` (`bukuid`);

--
-- Indexes for table `koleksipribadi`
--
ALTER TABLE `koleksipribadi`
  ADD PRIMARY KEY (`koleksi_id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `bukuid` (`bukuid`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`peminjamanid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `bukuid` (`bukuid`);

--
-- Indexes for table `ulasanbuku`
--
ALTER TABLE `ulasanbuku`
  ADD PRIMARY KEY (`ulasanid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `bukuid` (`bukuid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `bukuid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10007;

--
-- AUTO_INCREMENT for table `kategoribuku`
--
ALTER TABLE `kategoribuku`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3010;

--
-- AUTO_INCREMENT for table `kategoribuku_relasi`
--
ALTER TABLE `kategoribuku_relasi`
  MODIFY `kategoribuku_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4006;

--
-- AUTO_INCREMENT for table `koleksipribadi`
--
ALTER TABLE `koleksipribadi`
  MODIFY `koleksi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5013;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `peminjamanid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6019;

--
-- AUTO_INCREMENT for table `ulasanbuku`
--
ALTER TABLE `ulasanbuku`
  MODIFY `ulasanid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9006;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1105;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`kategori_id`) REFERENCES `kategoribuku` (`kategori_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kategoribuku_relasi`
--
ALTER TABLE `kategoribuku_relasi`
  ADD CONSTRAINT `kategoribuku_relasi_ibfk_1` FOREIGN KEY (`bukuid`) REFERENCES `buku` (`bukuid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `kategoribuku_relasi_ibfk_2` FOREIGN KEY (`kategori_id`) REFERENCES `kategoribuku` (`kategori_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `koleksipribadi`
--
ALTER TABLE `koleksipribadi`
  ADD CONSTRAINT `koleksipribadi_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `koleksipribadi_ibfk_3` FOREIGN KEY (`bukuid`) REFERENCES `buku` (`bukuid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`bukuid`) REFERENCES `buku` (`bukuid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ulasanbuku`
--
ALTER TABLE `ulasanbuku`
  ADD CONSTRAINT `ulasanbuku_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ulasanbuku_ibfk_2` FOREIGN KEY (`bukuid`) REFERENCES `buku` (`bukuid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
