<?php
if (empty($_SESSION['user']['level'] == 'Admin')) {
    if (empty($_SESSION['user']['level'] == 'Petugas')) {
?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            document.body.innerHTML = '';
            Swal.fire({
                icon: "error",
                title: "403 Forbidden.",
                text: "Akses Dilarang !",
            }).then(function() {
                window.history.back();
            })
        </script>
<?php
    }
}
?>
<h1 class="h3 mb-3">Kategori Buku</h1>

<div class="row">
    <div class="col-12">
        <div class="card flex-fill">
            <div class="card-body">
                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tambahkategori">+ Tambah Kategori</button>
                <br><br>
                <table class="table table-bordered table-striped table-hover cell-border" id="kategoribuku">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM kategoribuku");
                        while ($data = mysqli_fetch_array($query)) {
                        ?>
                            <tr>
                                <td><?php echo $i ?></td>
                                <td><?php echo $data['namakategori'] ?></td>
                                <td>
                                    <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editkategori<?php echo $data['kategori_id'] ?>"><i data-feather="edit"></i></button>
                                    <button class="btn btn-danger btn-sm" id="hapuskategori<?php echo $data['kategori_id'] ?>"><i data-feather="trash-2"></i></button>
                                </td>
                            </tr>
                            <!-- Modal Edit-->
                            <div class="modal fade" id="editkategori<?php echo $data['kategori_id'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="col-12">
                                                <div class="text-center">
                                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Kategori</h1>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" action="aksi-crud.php">
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="mb-3">
                                                        <input type="hidden" name="kategori_id" value="<?= $data['kategori_id'] ?>">
                                                        <label class="form-label">Nama Kategori</label>
                                                        <input type="text" name="namakategori" class="form-control" value="<?= $data['namakategori'] ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="col-12">
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-success" name="editkategori">Simpan</button>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit-->

                            <!-- SweetAlert Hapus-->
                            <script>
                                // Tambahkan event listener untuk tombol "Hapus Data"
                                document.getElementById('hapuskategori<?php echo $data['kategori_id'] ?>').addEventListener('click', function() {
                                    Swal.fire({
                                        title: 'Konfirmasi',
                                        text: 'Anda yakin ingin menghapus data ini?',
                                        icon: 'warning',
                                        showCancelButton: true,
                                        confirmButtonColor: '#3085d6',
                                        cancelButtonColor: '#d33',
                                        confirmButtonText: 'Ya, Hapus!',
                                        cancelButtonText: 'Batal'
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "aksi-crud.php?submit=hapuskategori&kategori_id=<?php echo $data['kategori_id'] ?>"
                                        }
                                    });
                                });
                            </script>
                            <!--Akhir SweetAlert Hapus-->

                        <?php
                            $i++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal Tambah-->
<div class="modal fade" id="tambahkategori" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Kategori</h1>
                    </div>
                </div>
            </div>
            <form method="post" action="aksi-crud.php">
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3">
                            <input type="hidden" name="kategori_id">
                            <label class="form-label">Nama Kategori</label>
                            <input type="text" name="namakategori" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-12">
                        <div class="text-center">
                            <button type="submit" class="btn btn-success" name="tambahkategori">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Akhir Modal Tambah-->

<script>
    let table = new DataTable('#kategoribuku');
</script>