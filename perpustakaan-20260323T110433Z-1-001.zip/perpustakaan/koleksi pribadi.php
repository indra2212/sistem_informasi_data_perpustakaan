<h1 class="h3 mb-3">Koleksi Pribadi</h1>

<div class="row">
    <div class="col-12">
        <div class="card flex-fill">
            <div class="card-body">
                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tambahkoleksi">+ Tambah Koleksi</button>
                <br><br>
                <table class="table table-bordered table-striped table-hover cell-border" id="koleksipribadi">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Peminjam</th>
                            <th>Judul</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $id = $_SESSION['user']['userid'];
                        $query = mysqli_query($koneksi, "SELECT * FROM koleksipribadi INNER JOIN user ON user.userid=koleksipribadi.userid INNER JOIN buku ON buku.bukuid=koleksipribadi.bukuid WHERE user.userid='$id'");
                        while ($data = mysqli_fetch_array($query)) {
                        ?>
                            <tr>
                                <td><?php echo $i ?></td>
                                <td><?php echo $data['namalengkap'] ?></td>
                                <td><?php echo $data['judul'] ?></td>
                                <td>
                                    <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editkoleksi<?php echo $data['koleksi_id'] ?>"><i data-feather="edit"></i></button>
                                    <button class="btn btn-danger btn-sm" id="hapuskoleksi<?php echo $data['koleksi_id'] ?>"><i data-feather="trash-2"></i></button>
                                </td>
                            </tr>
                            <!-- Modal Edit-->
                            <div class="modal fade" id="editkoleksi<?php echo $data['koleksi_id'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="col-12">
                                                <div class="text-center">
                                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Koleksi Pribadi</h1>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" action="aksi-crud.php">
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="mb-3">
                                                        <input type="hidden" name="koleksi_id" value="<?= $data['koleksi_id'] ?>">
                                                        <label class="form-label">Judul Buku</label>
                                                        <select name="bukuid" class="form-select" required>
                                                            <option value=""><?= $data['judul'] ?></option>
                                                            <?php
                                                            $query1 = mysqli_query($koneksi, "SELECT * FROM buku");
                                                            while ($buku = mysqli_fetch_array($query1)) {
                                                            ?>
                                                                <option value="<?php echo $buku['bukuid'] ?>"><?php echo $buku['judul'] ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="col-12">
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-success" name="editkoleksi">Simpan</button>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit-->

                            <!-- SweetAlert Hapus-->
                            <script>
                                // Tambahkan event listener untuk tombol "Hapus Data"
                                document.getElementById('hapuskoleksi<?php echo $data['koleksi_id'] ?>').addEventListener('click', function() {
                                    Swal.fire({
                                        title: 'Konfirmasi',
                                        text: 'Anda yakin ingin menghapus data ini?',
                                        icon: 'warning',
                                        showCancelButton: true,
                                        confirmButtonColor: '#3085d6',
                                        cancelButtonColor: '#d33',
                                        confirmButtonText: 'Ya, Hapus!',
                                        cancelButtonText: 'Batal'
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "aksi-crud.php?submit=hapuskoleksi&koleksi_id=<?php echo $data['koleksi_id'] ?>"
                                        }
                                    });
                                });
                            </script>
                            <!--Akhir SweetAlert Hapus-->

                        <?php
                            $i++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal Tambah-->
<div class="modal fade" id="tambahkoleksi" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Koleksi</h1>
                    </div>
                </div>
            </div>
            <form method="post" action="aksi-crud.php">
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3">
                            <label class="form-label">Judul Buku</label>
                            <select name="bukuid" class="form-select" required>
                                <option value="">-Pilih-</option>
                                <?php
                                $query = mysqli_query($koneksi, "SELECT * FROM buku");
                                while ($buku = mysqli_fetch_array($query)) {
                                ?>
                                    <option value="<?php echo $buku['bukuid'] ?>"><?php echo $buku['judul'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-12">
                        <div class="text-center">
                            <button type="submit" class="btn btn-success" name="tambahkoleksi">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Akhir Modal Tambah-->

<script>
    let table = new DataTable('#koleksipribadi');
</script>