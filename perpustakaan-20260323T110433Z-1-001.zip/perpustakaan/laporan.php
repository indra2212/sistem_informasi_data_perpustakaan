<?php
if (empty($_SESSION['user']['level'] == 'Admin')) {
    if (empty($_SESSION['user']['level'] == 'Petugas')) {
?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            document.body.innerHTML = '';
            Swal.fire({
                icon: "error",
                title: "403 Forbidden.",
                text: "Akses Dilarang !",
            }).then(function() {
                window.history.back();
            })
        </script>
<?php
    }
}
?>
<div class="row">
    <div class="col-12">
        <div class="card flex-fill">
            <div class="card-body">
                <table class="table table-bordered table-striped table-hover cell-border" id="laporan">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Peminjam</th>
                            <th>Buku Yang Dipinjam</th>
                            <th>Tanggal Peminjaman</th>
                            <th>Tanggal Pengembalian</th>
                            <th>Status Peminjaman</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $no = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM peminjaman INNER JOIN user ON user.userid=peminjaman.userid INNER JOIN buku ON buku.bukuid=peminjaman.bukuid");
                        while ($data = mysqli_fetch_array($query)) {
                        ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td><?php echo $data['namalengkap'] ?></td>
                                <td><?php echo $data['judul'] ?></td>
                                <td><?php echo $data['tanggalpeminjaman'] ?></td>
                                <td><?php echo $data['tanggalpengembalian'] ?></td>
                                <td><?php echo $data['statuspeminjaman'] ?></td>
                            <?php
                        }
                            ?>

                            </td>
                            </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        feather.replace(); // Replace icons with Feather Icons

        // Cek apakah DataTable sudah diinisialisasi 
        if (!$.fn.DataTable.isDataTable('#laporan')) {
            $('#laporan').DataTable({
                dom: 'Bfrtip',
                buttons: [{
                    extend: 'print',
                    text: '<span data-feather="printer">Print</span>',
                    className: 'btn btn-primary',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5]
                    }
                }]
            });
        }
    });
</script>