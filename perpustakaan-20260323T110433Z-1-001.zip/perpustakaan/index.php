<?php
include 'koneksi.php';
if (empty($_SESSION['user'])) {
	header('location: login.php');
}

// Define access levels
$adminLevel = 'admin';
$petugasLevel = 'petugas';
$peminjamLevel = 'peminjam';

$userLevel = $_SESSION['user']['level'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />
	<link rel="canonical" href="https://demo-basic.adminkit.io/" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.css">


	<!-- CSS Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<!-- DataTables -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
	<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
	<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
	<!-- SweetAlert -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

	<title> Perpustakaan |
		<?php
		$page = isset($_GET['page']) ? $_GET['page'] : 'Dashboard';
		$cek = preg_replace('/-/', ' ', $page);
		$title = ucwords($cek);
		echo $title;
		?>
	</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.php">
					<span class="align-middle">Perpustakaan</span>
				</a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Halaman
					</li>

					<li class="sidebar-item 
					<?php
					if (empty($_GET['page'])) {
						echo 'active';
					}
					?>">
						<a class="sidebar-link" href="index.php">
							<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
						</a>
					</li>

					<?php
					if (!empty($_SESSION['user']['level'] == 'Admin')) {
					?>
						<li class="sidebar-item 
					<?php
						if ($page == 'user') {
							echo 'active';
						}
					?>">
							<a class="sidebar-link" href="?page=user">
								<i class="align-middle" data-feather="user"></i> <span class="align-middle">Pengguna</span>
							</a>
						</li>
					<?php
					}
					?>

					<?php
					if (empty($_SESSION['user']['level'] == 'Peminjam')) {
					?>

						<li class="sidebar-item 
					<?php
						if ($page == 'buku') {
							echo 'active';
						}
					?>">
							<a class="sidebar-link" href="?page=buku">
								<i class="align-middle" data-feather="book"></i> <span class="align-middle">Buku</span>
							</a>
						</li>

					<?php
					}
					?>

					<li class="sidebar-item
					<?php
					if ($page == 'ulasan buku') {
						echo 'active';
					}
					?>">
						<a class="sidebar-link" href="?page=ulasan+buku">
							<i class="align-middle" data-feather="bookmark"></i> <span class="align-middle">Ulasan Buku</span>
						</a>
					</li>

					<li class="sidebar-item
					<?php
					if ($page == 'peminjaman') {
						echo 'active';
					}
					?>">
						<a class="sidebar-link" href="?page=peminjaman">
							<i class="align-middle" data-feather="bookmark"></i> <span class="align-middle">Peminjaman Buku</span>
						</a>
					</li>

					<?php
					if (empty($_SESSION['user']['level'] == 'Peminjam')) {
					?>

						<li class="sidebar-item
					<?php
						if ($page == 'kategori buku') {
							echo 'active';
						}
					?>">
							<a class="sidebar-link" href="?page=kategori+buku">
								<i class="align-middle" data-feather="folder-plus"></i> <span class="align-middle">Kategori Buku</span>
							</a>
						</li>

					<?php
					}
					?>

					<li class="sidebar-item 
					<?php
					if ($page == 'koleksi pribadi') {
						echo 'active';
					}
					?>">
						<a class="sidebar-link" href="?page=koleksi+pribadi">
							<i class="align-middle" data-feather="star"></i> <span class="align-middle">Koleksi Pribadi</span>
						</a>
					</li>

					<?php
					if (empty($_SESSION['user']['level'] == 'Peminjam')) {
					?>

						<li class="sidebar-item
					<?php
						if ($page == 'laporan') {
							echo 'active';
						}
					?>">
							<a class="sidebar-link" href="?page=laporan">
								<i class="align-middle" data-feather="printer"></i> <span class="align-middle">Laporan</span>
							</a>
						</li>

					<?php
					}
					?>



					<?php
					if (empty($_SESSION['user']['level'] == 'Petugas')) {
					?>
						<div class="sidebar-cta">
							<div class="sidebar-cta-content">
								<strong class="d-inline-block mb-2">Menu</strong>
								<?php
								if (!empty($_SESSION['user']['level'] == 'Peminjam')) {
								?>
									<div class="d-grid">
										<button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tambahpeminjaman">Pinjam Buku</button>
									</div>
								<?php
								}
								?>
								<br>
								<?php
								if (!empty($_SESSION['user']['level'] == 'Admin')) {
								?>
									<div class="d-grid">
										<button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tambahuser">Registrasi Admin</button>
									</div>
								<?php
								}
								?>
							</div>
						</div>
					<?php
					}
					?>
				</ul>
			</div>
		</nav>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle js-sidebar-toggle">
					<i class="hamburger align-self-center"></i>
				</a>

				<div class="navbar-collapse collapse">
					<ul class="navbar-nav navbar-align">
						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle" href="?page=profile" id="alertsDropdown" data-bs-toggle="dropdown">

							</a>
						</li>

						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="?page=profile" data-bs-toggle="dropdown">
								<i class="align-middle" data-feather="settings"></i>
							</a>

							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="" data-bs-toggle="dropdown">
								<span class="text-dark"><?php echo $_SESSION['user']['namalengkap'] ?></span>
							</a>
							<div class="dropdown-menu dropdown-menu-end">
								<a class="dropdown-item" href="?page=profile"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="logout.php">Log out</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<main class="content">
				<div class="container-fluid p-0">

					<?php
					$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
					include $page . '.php';
					?>

			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>AdminKit</strong></a> - <a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Bootstrap Admin Template</strong></a> &copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="js/app.js"></script>
	<!-- Modal Tambah-->
	<div class="modal fade" id="tambahpeminjaman" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<div class="col-12">
						<div class="text-center">
							<h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Peminjaman</h1>
						</div>
					</div>
				</div>
				<form method="post" action="aksi-crud.php">
					<div class="modal-body">
						<div class="row">
							<div class="mb-3">
								<label class="form-label">Nama Peminjam</label>
								<input type="text" class="form-control" value="<?php echo $_SESSION['user']['namalengkap'] ?>" disabled>
							</div>
							<div class="mb-3">
								<label class="form-label">Buku yang Dipinjam</label>
								<select name="bukuid" class="form-select">
									<?php
									$query = mysqli_query($koneksi, "SELECT * FROM buku");
									while ($data = mysqli_fetch_array($query)) {
									?>
										<option value="<?php echo $data['bukuid'] ?>"><?php echo $data['judul'] ?></option>
									<?php
									}
									?>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label">Tanggal Peminjaman</label>
								<input type="date" name="tanggalpeminjaman" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Tanggal Pengembalian</label>
								<input type="date" name="tanggalpengembalian" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Status Peminjaman</label>
								<input type="text" name="statuspeminjaman" class="form-control" required>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<div class="col-12">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="tambahpeminjaman">Simpan</button>
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Akhir Modal Tambah-->

	<!-- Modal Tambah-->
	<div class="modal fade" id="tambahuser" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<div class="col-12">
						<div class="text-center">
							<h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Pengguna</h1>
						</div>
					</div>
				</div>
				<form method="post" action="aksi-crud.php">
					<div class="modal-body">
						<div class="row">
							<div class="mb-3">
								<label class="form-label">Username</label>
								<input type="text" name="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Password</label>
								<input type="password" name="password" class="form-control" required>
							</div>
							<div class="mb-3">
								<input type="hidden" name="userid">
								<label class="form-label">Nama Lengkap</label>
								<input type="text" name="namalengkap" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Email</label>
								<input type="email" name="email" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Alamat</label>
								<input type="text" name="alamat" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Level</label>
								<select name="level" class="form-select">
									<option value="admin">Admin</option>
									<option value="petugas">Petugas</option>
									<option value="petugas">Peminjam</option>
								</select>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<div class="col-12">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="tambahuser">Simpan</button>
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Akhir Modal Tambah-->

	<?php
	if (isset($_SESSION['icon'])) {
	?>
		<script>
			Swal.fire({
				icon: "<?php echo $_SESSION['icon'] ?>",
				title: "<?php echo $_SESSION['title'] ?>",
				text: "<?php echo $_SESSION['text'] ?>",
			})
		</script>
	<?php
		unset($_SESSION['icon']);
	}
	?>
</body>

</html>