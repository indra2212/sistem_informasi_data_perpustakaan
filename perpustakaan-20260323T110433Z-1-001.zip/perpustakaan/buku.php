<?php
if (empty($_SESSION['user']['level'] == 'Admin')) {
    if (empty($_SESSION['user']['level'] == 'Petugas')) {
?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            document.body.innerHTML = '';
            Swal.fire({
                icon: "error",
                title: "403 Forbidden.",
                text: "Akses Dilarang !",
            }).then(function() {
                window.history.back();
            })
        </script>
<?php
    }
}
?>
<h1 class="h3 mb-3">Buku</h1>

<div class="row">
    <div class="col-12">
        <div class="card flex-fill">
            <div class="card-body">
                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tambahbuku">+ Tambah Buku</button>
                <br><br>
                <table class="table table-bordered table-striped table-hover cell-border" id="buku">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Kategori Buku</th>
                            <th>Penulis</th>
                            <th>Penerbit</th>
                            <th>Tahun Terbit</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM buku INNER JOIN kategoribuku ON kategoribuku.kategori_id=buku.kategori_id");
                        while ($data = mysqli_fetch_array($query)) {
                        ?>
                            <tr>
                                <td><?php echo $i ?></td>
                                <td><?php echo $data['judul'] ?></td>
                                <td><?php echo $data['namakategori'] ?></td>
                                <td><?php echo $data['penulis'] ?></td>
                                <td><?php echo $data['penerbit'] ?></td>
                                <td><?php echo $data['tahunterbit'] ?></td>
                                <td>
                                    <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#editbuku<?php echo $data['bukuid'] ?>"><i data-feather="edit"></i></button>
                                    <button class="btn btn-danger btn-sm" id="hapusbuku<?php echo $data['bukuid'] ?>"><i data-feather="trash-2"></i></button>
                                </td>
                            </tr>
                            <!-- Modal Edit-->
                            <div class="modal fade" id="editbuku<?php echo $data['bukuid'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="col-12">
                                                <div class="text-center">
                                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Buku</h1>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" action="aksi-crud.php">
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="mb-3">
                                                        <input type="hidden" name="bukuid" value="<?= $data['bukuid'] ?>">
                                                        <label class="form-label">Judul</label>
                                                        <input type="text" name="judul" class="form-control" value="<?= $data['judul'] ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Kategori Buku</label>
                                                        <select name="kategori_id" class="form-select">
                                                            <?php
                                                            $query1 = mysqli_query($koneksi, "SELECT * FROM kategoribuku");
                                                            while ($kategori = mysqli_fetch_array($query1)) {
                                                            ?>
                                                                <option value="<?php echo $kategori['kategori_id'] ?>" <?php echo ($data['kategori_id'] == $kategori['kategori_id'] ? 'selected' : '') ?>>
                                                                    <?php echo $kategori['namakategori'] ?>
                                                                </option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Penulis</label>
                                                        <input type="text" name="penulis" class="form-control" value="<?= $data['penulis'] ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Penerbit</label>
                                                        <input type="text" name="penerbit" class="form-control" value="<?= $data['penerbit'] ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Tahun Terbit</label>
                                                        <input type="text" name="tahunterbit" class="form-control" value="<?= $data['tahunterbit'] ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="col-12">
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-success" name="editbuku">Simpan</button>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Modal Edit-->

                            <!-- SweetAlert Hapus-->
                            <script>
                                // Tambahkan event listener untuk tombol "Hapus Data"
                                document.getElementById('hapusbuku<?php echo $data['bukuid'] ?>').addEventListener('click', function() {
                                    Swal.fire({
                                        title: 'Konfirmasi',
                                        text: 'Anda yakin ingin menghapus data ini?',
                                        icon: 'warning',
                                        showCancelButton: true,
                                        confirmButtonColor: '#3085d6',
                                        cancelButtonColor: '#d33',
                                        confirmButtonText: 'Ya, Hapus!',
                                        cancelButtonText: 'Batal'
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "aksi-crud.php?submit=hapusbuku&bukuid=<?php echo $data['bukuid'] ?>"
                                        }
                                    });
                                });
                            </script>
                            <!--Akhir SweetAlert Hapus-->

                        <?php
                            $i++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal Tambah-->
<div class="modal fade" id="tambahbuku" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Buku</h1>
                    </div>
                </div>
            </div>
            <form method="post" action="aksi-crud.php">
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3">
                            <input type="hidden" name="bukuid">
                            <label class="form-label">Judul</label>
                            <input type="text" name="judul" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori Buku</label>
                            <select name="kategori_id" class="form-select">
                                <?php
                                $query = mysqli_query($koneksi, "SELECT * FROM kategoribuku");
                                while ($data = mysqli_fetch_array($query)) {
                                ?>
                                    <option value="<?php echo $data['kategori_id'] ?>"><?php echo $data['namakategori'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Penulis</label>
                            <input type="text" name="penulis" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Penerbit</label>
                            <input type="text" name="penerbit" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tahun Terbit</label>
                            <input type="text" name="tahunterbit" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-12">
                        <div class="text-center">
                            <button type="submit" class="btn btn-success" name="tambahbuku">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Akhir Modal Tambah-->

<script>
    let table = new DataTable('#buku');
</script>