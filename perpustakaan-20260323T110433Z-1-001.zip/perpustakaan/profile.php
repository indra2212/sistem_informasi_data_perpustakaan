<div class="mb-3">
	<h1 class="h3 d-inline align-middle">Profile</h1>
</div>
<div class="row">
	<div class="col-5">
		<div class="card">
			<div class="card-header">
				<h5 class="card-title mb-0 text-center">Profile User</h5>
			</div>
			<div class="card-body h-100">
				<form action="" method="post">
					<div class=" mb-3">
						<label class="form-label">Nama Lengkap</label>
						<div class="col-12">
							<input type="text" name="nama" class="form-control" value="<?php echo $_SESSION['user']['namalengkap'] ?>" disabled>
						</div>
					</div>
					<div class="mb-3">
						<label class="form-label">Username</label>
						<div class="col-12">
							<input type="text" name="username" class="form-control" value="<?php echo $_SESSION['user']['username'] ?>" disabled>
						</div>
					</div>
					<div class="mb-3">
						<label class="form-label">Email</label>
						<div class="col-12">
							<input type="email" name="email" class="form-control" value="<?php echo $_SESSION['user']['email'] ?>" disabled>
						</div>
					</div>
					<div class="mb-3">
						<label class="form-label">Alamat</label>
						<div class="col-12">
							<input type="text" name="alamat" class="form-control" value="<?php echo $_SESSION['user']['alamat'] ?>" disabled>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>